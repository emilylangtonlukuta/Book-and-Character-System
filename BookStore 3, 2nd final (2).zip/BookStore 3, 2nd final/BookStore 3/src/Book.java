/**
 * 
 * @authors Emily Lukuta and Ashraf Abdulhameed
 * 
 * This is a java system that enables a user to add, delete , view/sort, edit/update, search , 
 * save and load books and characters
 * 
 * Book class 
 */

public class Book implements Comparable<Book>{
/**
 * variables for book class 
 */
	public String title;
	public String author;
	public int yearOfPublication;
	public String publisher;
	public int noPages;
	public String genre;
	public String Description;
	public int bookId;
	
	/** 
	 * linkedlist for character class from generic linkedlist
	 */
	public MyList<Character> charList= new MyList<>();
	
	/**
	 * Constructor.
	 * 
	 * @param title
	 * @param author
	 * @param publisher
	 * @param yearOfPublication
	 * @param noPages
	 * @param description
	 * @param genre
	 * @param bookId
	 */
	public Book(String title, String author, String publisher, int yearOfPublication, int noPages, String description, String genre, int bookId) {
		this.title = title;
		this.author=author;
		this.yearOfPublication = yearOfPublication;
		this.publisher = publisher;
		this.noPages = noPages;
		this.genre = genre;
		this.Description = description;
		this.bookId = bookId;
		
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * methods to associate character witk book 
	 */
	public void addCharacter(String name, String gender, int id, String description, String chBook) {
		Character c = new Character(name, gender, id, description, chBook);
		charList.addElement(c);
		c.associateCharacterWithBook(this);
	}

	public void addCharacter(Character c) {
		charList.addElement(c);
		c.associateCharacterWithBook(this);
		
	}
	public void associateCharacter(Character character) {
		charList.addElement(character);
		}
	
	/**
	 * getters and setters
	 */
	public String getTitle() {
		return title;
	}



	public void setTitle(String title) {
		this.title = title;
	}



	public String getAuthor() {
		return author;
	}



	public void setAuthor(String author) {
		this.author = author;
	}



	public int getYearOfPublication() {
		return yearOfPublication;
	}



	public void setYearOfPublication(int yearOfPublication) {
		this.yearOfPublication = yearOfPublication;
	}



	public String getPublisher() {
		return publisher;
	}



	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}



	public int getNoPages() {
		return noPages;
	}



	public void setNoPages(int noPages) {
		this.noPages = noPages;
	}



	public String getGenre() {
		return genre;
	}



	public void setGenre(String genre) {
		this.genre = genre;
	}



	public String getDescription() {
		return Description;
	}



	public void setDescription(String description) {
		Description = description;
	}



	public int getBookId() {
		return bookId;
	}



	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	/*public boolean equals(Object) {
		return title.equals(((Book)o).title);
	}*/
/**
 * To String Method
 */
	@Override
	public String toString() {
		return "Book [title=" + title + ", author=" + author + ", yearOfPublication=" + yearOfPublication
				+ ", publisher=" + publisher + ", noPages=" + noPages + ", genre=" + genre + ", Description="
				+ Description + ", bookId=" + bookId + "]";
	}


/**
 * Compares the object with specifies object for order 
 * used for search() methods for name search, author search and genre search
 */
	@Override
	public int compareTo(Book b) {
		return this.getTitle().compareTo(b.getTitle());
	}
	public int compareToAuthor(Book b) {
		return this.getAuthor().hashCode() - b.getAuthor().hashCode();
	}
	public int compareToGenre(Book b) {
		return this.getGenre().hashCode() - b.getGenre().hashCode();
	}

	
	
}

import java.util.Scanner;

/**
 * 
 * @author Emily Lukuta and Ashraf Abdulhameed.
 *Book Hashtable Class
 */
public class BookTable {
	
	private Book[] hashTable;
	private static final int MAX_PROBES=500; //Or could use a factor of the hash table size for max probes
	private static final double MAX_LOAD_FACTOR=1.0; 

	
	public BookTable(int size){
		hashTable=new Book[size];
	}
	
	
	public int hashFunction(Book bk){
		return bk.hashCode()%hashTable.length;
	}
	
	public double loadFactor() {
		double usedSlots=0;
		for(Book x : hashTable) if(x!= null) usedSlots++;
		return usedSlots/hashTable.length;
	}
	/**
	 * 
	 * @param book Method for adding a book into the system.
	 * @return
	 */
	public int add(Book book){
		int location=hashFunction(book);
		int probeCount=0;
		
		do{
			if(hashTable[location]==null) {
				hashTable[location] = book;
				return location;
			}
			
			probeCount++;
			location=(hashFunction(book)+(probeCount*probeCount))%hashTable.length;
			
		}while(loadFactor()<MAX_LOAD_FACTOR && probeCount<MAX_PROBES);
		
		
		System.out.println("Cannot store "+book+" (Load Factor: "+loadFactor()+", Probes: "+probeCount);
		return -1;
	}
	
	public int size() {
		return hashTable.length;
	}
	
	/**
	 * Methods for Listing out the books in the system.
	 * @return
	 */
	public String listBooks(){
		System.out.println("List of all books");
		System.out.println("===============================");
		for(int i=0;i<hashTable.length;i++)
			System.out.println("Location "+i+": "+
					(hashTable[i]!=null ? hashTable[i] : "Empty"));
		System.out.println();
		return "";
	}
	public String listBooks(Book[] book){
		System.out.println("List of all books");
		System.out.println("===============================");
		for(int i=0;i<book.length;i++)
			if(book[i]!=null) System.out.println("Location "+i+": "+book[i].title +", "+book[i].author +", "+book[i].yearOfPublication +", "+book[i].publisher + ","+ book[i].noPages +","+ book[i].genre + "," +book[i].Description + ","+ book[i].bookId );
		System.out.println();
	
	
		return "";
	}

	public Book getByIndex(int index) {
		return this.hashTable[index];
	}
	
/**
 * Methods for sorting the list of Books in the system A-Z.
 * @return
 */
	public Book[] sort() {
		Book[] copy = this.copyTable();
		
		for(int i = 0; i < copy.length - 1; i++) {
			
			int newIndex = i;
			
			for(int j = i + 1; j < copy.length; j++) {
				if(copy[i] == null && copy[j] != null) {
					Book temp = copy[i];
					copy[i] = copy[j];
					copy[j] = temp;
				}
				if(copy[i] != null && copy[j] != null && copy[i].compareTo(copy[j]) > 0) {
					newIndex = j;
				}
			}
			
			if(newIndex != i) {
				Book temp = copy[i];
				copy[i] = copy[newIndex];
				copy[newIndex] = temp;
			}
			
			
		}
		
		return copy;
	}
	
	/**
	 * Method for Searching the Book by the name of a Book in the System.
	 * @param query 
	 * @return
	 */
	public Book search(String query) {
		Book[] sortedList = this.sort();
		
		Book book = new Book(query, null,null, 0, 0, null,null, 0 );
		
		int low = 0;
		int middle;
		int high = sortedList.length - 1;
		
		do{
			middle=(low+high)/2;
			if(sortedList[middle] == null || sortedList[middle].compareTo(book)> 0) high=middle-1;
			else if(sortedList[middle].compareTo(book) == 0) return sortedList[middle];
			else low=middle+1;
		}while(low<=high);
		
		return null;
		
	}
	
	/**
	 * Method for Searching the Book by the Author of a book in the System. 
	 * @param query
	 * @return
	 */
	public Book searchAuthor(String query) {
		Book[] sortedList = this.sort();
		
		Book book = new Book(null, query,null, 0, 0, null,null, 0 );
		
		int low = 0;
		int middle;
		int high = sortedList.length - 1;
		
		do{
			middle=(low+high)/2;
			if(sortedList[middle] == null || sortedList[middle].compareToAuthor(book)> 0) high=middle-1;
			else if(sortedList[middle].compareToAuthor(book) == 0) return sortedList[middle];
			else low=middle+1;
		}while(low<=high);
		
		return null;
		
	}
	
	/**
	 * Method for searching the Book by the Genre in the System.
	 * @param query
	 * @return
	 */
	public Book searchGenre(String query) {
		Book[] sortedList = this.sort();
		
		Book book = new Book(null, null,null, 0, 0, null,query, 0 );
		
		int low = 0;
		int middle;
		int high = sortedList.length - 1;
		
		do{
			middle=(low+high)/2;
			if(sortedList[middle] == null || sortedList[middle].compareToGenre(book)> 0) high=middle-1;
			else if(sortedList[middle].compareToGenre(book) == 0) return sortedList[middle];
			else low=middle+1;
		}while(low<=high);
		
		return null;
		
	}
	
	/**
	 * Method to copy book hashtable in order to be used for sorting.
	 * @return
	 */
	public Book[] copyTable() {
		Book[] copy = new Book[hashTable.length];
		
		for(int i = 0; i < hashTable.length; i++) {
			copy[i] = hashTable[i];
		}
		
		return copy;	
	}
	
	/**
	 *Method to Delete/Remove a Book from the System. 
	 */
	public boolean removeItem(Book book) {    	
		for(int i = 0; i < hashTable.length; i++) {
			if(book.equals(hashTable[i])) {
				hashTable[i] = null;
				return true;
			}
		}
	return false;
	
	}}

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
/**
 * 
 * @author Emily Lukuta and Ashraf Abdulhameed
 * 
 * Test case for Getters and Setters for Book class.
 *
 */
class BookTestCase {

	Book b;

	@BeforeEach
	void setUp() throws Exception{
		b = new Book(null, null, null, 0, 0, null, null, 0);
		b.setTitle("Fault in our Stars");
		b.setAuthor("John Green");
		b.setGenre("Romcom");
		b.setNoPages(456);
		b.setPublisher("Veronica Roth");
		b.setYearOfPublication(2018);
		b.setBookId(76);
	}

	@Test
	void getTitleTest() {
		assertEquals("Fault in our Stars", b.getTitle());
	}

	@Test
	void setTitleTest() {
		assertEquals("Fault in our Stars", b.getTitle());
		b.setTitle("Fault in our Stars");
		assertEquals("Fault in our Stars", b.getTitle());
	}

	@Test
	void getAuthorTest() {
		assertEquals("John green", b.getAuthor());
	}

	@Test
	void setAuthorTest() {
		assertEquals("John Green", b.getAuthor());
		b.setAuthor("Suzanne Collins");
		assertEquals("Suzanne Collins", b.getAuthor());
	}

	@Test
	void getGenreTest() {
		assertEquals("Romcom", b.getGenre());
	}

	@Test
	void setGenreTest() {
		assertEquals("Romcom", b.getGenre());
		b.setGenre("Thriller");
		assertEquals("Triller", b.getGenre());
	}

	@Test
	void getNoPagesTest() {
		assertEquals(456, b.getNoPages());
	}

	@Test 
	void setNoPagesTest() {
		assertEquals(456, b.getNoPages());
		b.setNoPages(1051);
		assertEquals(452, b.getNoPages());
	}
	
	

	@Test
	void setPublisherTest() {
		assertEquals("Veronica Roth", b.getPublisher());
		b.setGenre("Veronica Roth");
		assertEquals("Veronica Roth", b.getPublisher());}
		
		@Test
		void getPublisherTest() {
			assertEquals("Veronica Roth", b.getPublisher());
		}

		@Test
		void setYearOfPublicationTest() {
			assertEquals(2013, b.getYearOfPublication());
			b.setYearOfPublication(2013);
			assertEquals(2013, b.getYearOfPublication());}	
	
			@Test
			void getYearOfPublicationTest() {
				assertEquals(2013, b.getYearOfPublication());
			}

	
	}


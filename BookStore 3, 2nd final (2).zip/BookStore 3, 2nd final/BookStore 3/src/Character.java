/**
 * 
 * @author Emily Lukuta and Ashraf Abdulhameed
 * 
 *Character Class.
 */
public class Character implements Comparable<Character> {
	
	/**
	 * Instances/Variables
	 */
		public String name;
		public String gender ;
		public int id;
		public String description;
		public String chBook;
		
		
		/**
		 * linkedlist for book class from generic linkedlist
		 */
		public MyList<Book> bookList= new MyList<>();
		
		
		/**
		 * Constructor .
		 * 
		 * @param name
		 * @param gender
		 * @param id
		 * @param description
		 * @param chBook
		 */
		public Character(String name, String gender, int id, String description, String chBook) {
			this.name = name;
			this.gender = gender;
			this.chBook = chBook;
			this.id = id;
			this.description = description;
			
			}
			
/**
 * Getters and Setters 
 */
		public void associateCharacterWithBook(Book b) {
			bookList.addElement(b);
		}


		public String getChBook() {
			return chBook;
		}

		public void setChBook(String chBook) {
			this.chBook = chBook;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getGender() {
			return gender;
		}

		public void setGender(String gender) {
			if(gender.equals("M") || gender.equals("m"))
		        this.gender = "M";
		   else if(gender.equals("F" )|| gender.equals("f"))
				 this.gender = "F";
			else
					 this.gender = "Unspecified";
		    	 
		}

		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public String getDescription() {
			return description;
		}

		public void setDescription(String description) {
			this.description = description;
		}
		
		/**
		 * Compares the object with specifies object for order 
		 * used for search() methods for name search and charcater book title search
		 */
		@Override
		public int compareTo(Character c) {
			return this.getName().compareTo(c.getName());
		}
		public int compareToChBook(Character c) {
			return this.getChBook().hashCode() - c.getChBook().hashCode();
		}

		@Override
		public String toString() {
			return "Character [name=" + name + ", gender=" + gender + ", id=" + id + ", description=" + description
					+ ", chBook=" + chBook + "]";
		}


		public void associateBook(Book book) {
			bookList.addElement(book);
		}

	
	}

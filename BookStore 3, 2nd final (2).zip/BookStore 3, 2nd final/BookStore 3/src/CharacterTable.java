import java.util.Scanner;

/**
 * 
 * @author Emily Lukuta and Ashraf Abdulhameed.
 * 
 *Character Hashtable Class
 */
public class CharacterTable {
	
	/**
	 * Instances/Variables.
	 */
	private Character[] hashTable;
	private static final int MAX_PROBES=500; //Or could use a factor of the hash table size for max probes
	private static final double MAX_LOAD_FACTOR=1.0; 
	private BookTable bookTable;
	private Book book;
	
	public CharacterTable(int size){
		hashTable=new Character[size];
	}
	
	
	public int hashFunction(Character ch){
		return ch.hashCode()%hashTable.length;
	}
	
	public double loadFactor() {
		double usedSlots=0;
		for(Character x : hashTable) if(x!= null) usedSlots++;
		return usedSlots/hashTable.length;
	}
	
	/**
	 * Adds Character to the System.
	 * @param character
	 * @return
	 */
	public int add(Character character){
		int location=hashFunction(character);
		int probeCount=0;
		
		do{
			if(hashTable[location]==null) {
				hashTable[location] = character;
				return location;
			}
			
			probeCount++;
			location=(hashFunction(character)+(probeCount*probeCount))%hashTable.length;
			
		}while(loadFactor()<MAX_LOAD_FACTOR && probeCount<MAX_PROBES); 
		
		System.out.println("Cannot store "+character+" (Load Factor: "+loadFactor()+", Probes: "+probeCount);
		return -1;
	}
	
	/**
	 * Deletes/Removes character from the System.
	 * @param character
	 * @return
	 */
    public boolean removeItem(Character character) {    	
		for(int i = 0; i < hashTable.length; i++) {
			if(character.equals(hashTable[i])) {
				hashTable[i] = null;
				return true;
			}
		}
			
		return false;
	}
	
	public int size() {
		return hashTable.length;
	}
	
	/**
	 * Sorts the Characters in the System A-Z.
	 * @return
	 */
	public Character[] sort() {
		Character[] copy = this.copyTable();
		
		for(int i = 0; i < copy.length - 1; i++) {
			
			int newIndex = i;
			
			for(int j = i + 1; j < copy.length; j++) {
				if(copy[i] == null && copy[j] != null) {
					Character temp = copy[i];
					copy[i] = copy[j];
					copy[j] = temp;
				}
				if(copy[i] != null && copy[j] != null && copy[i].compareTo(copy[j]) > 0) {
					newIndex = j;
				}
			}
			
			if(newIndex != i) {
				Character temp = copy[i];
				copy[i] = copy[newIndex];
				copy[newIndex] = temp;
			}
			
			
		}
		
		return copy;
	}
	
	/**
	 * Method for searching a character by Charcter name in the System.
	 * @param query
	 * @return
	 */
	public Character search(String query) {
		Character[] sortedList = this.sort();
		
		Character character = new Character(query, null, 0, null, null);
		
		int low = 0;
		int middle;
		int high = sortedList.length - 1;
		
		do{
			middle=(low+high)/2;
			if(sortedList[middle] == null || sortedList[middle].compareTo(character)> 0) high=middle-1;
			else if(sortedList[middle].compareTo(character) == 0) return sortedList[middle];
			else low=middle+1;
		}while(low<=high);
		
		return null;
		
	}
	
	/**
	 * Method for searching Character by book title in the system.
	 * @param query
	 * @return
	 */
	public Character searchChBook(String query) {
Character[] sortedList = this.sort();
		
		Character character = new Character(null, null, 0, null, query);
		
		int low = 0;
		int middle;
		int high = sortedList.length - 1;
		
		do{
			middle=(low+high)/2;
			if(sortedList[middle] == null || sortedList[middle].compareToChBook(character)> 0) high=middle-1;
			else if(sortedList[middle].compareToChBook(character) == 0) return sortedList[middle];
			else low=middle+1;
		}while(low<=high);
		
		return null;
	}
	
	public Character getByIndex(int index) {
		return this.hashTable[index];
	}
	
	/**
	 * Method to copy character hashtable in order to be used for sorting.
	 * @return
	 */
	public Character[] copyTable() {
		Character[] copy = new Character[hashTable.length];
		
		for(int i = 0; i < hashTable.length; i++) {
			copy[i] = hashTable[i];
		}
		
		return copy;	
	}
	
	/**
	 * Methods for Listing Characters in the System
	 * @return
	 */
	public String listCharacters(){
		System.out.println("List of all characters");
		System.out.println("===============================");
		for(int i=0;i<hashTable.length;i++)
			System.out.println("Location "+i+": "+
					(hashTable[i]!=null ? hashTable[i] : "Empty"));
		System.out.println();
	
	
		return "";
	}
	public String listCharacters(Character[] characters){
		System.out.println("List of all characters");
		System.out.println("===============================");
		for(int i=0;i<characters.length;i++)
			if(characters[i]!=null) System.out.println("Location "+i+": "+characters[i].name +", "+characters[i].gender +", "+characters[i].id +", "+characters[i].chBook+", "+characters[i].description);
		System.out.println();
	
		return "";
	}
}

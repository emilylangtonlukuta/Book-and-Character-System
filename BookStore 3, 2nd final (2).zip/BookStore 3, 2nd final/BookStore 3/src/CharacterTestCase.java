import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
/**
 * 
 * @author Emily Lukuta and Ashraf Abdulhameed
 * 
 * Test case for Getters and Setters for Character class.
 *
 */
class CharacterTestCase {

	Character c;
	
	@BeforeEach
	void setUp() throws Exception{
		c = new Character(null, null, 0, null, null);
		c.setName("Emily");
		c.setGender("Female");
		c.setId(89);
		c.setDescription("Ashraf Abdulhameed");
		c.setChBook("Group Work");
	}

	@Test
	void getNameTest() {
		assertEquals("Emily", c.getName());
	}

	@Test
	void setNameTest() {
		assertEquals("Emily", c.getName());
		c.setName("Emily");
		assertEquals("Emily", c.getName());
	}

	@Test
	void getGenderTest() {
		assertEquals("Female", c.getGender());
	}

	@Test
	void setGenderTest() {
		assertEquals("Female", c.getGender());
		c.setGender("Female");
		assertEquals("Female", c.getGender());
	}

	@Test
	void getIdTest() {
		assertEquals(89, c.getId());
	}

	@Test
	void setIdTest() {
		assertEquals(89, c.getId());
		c.setId(78);
		assertEquals(78, c.getId());
	}

	@Test
	void getDescriptionTest() {
		assertEquals("Ashraf Abdulhameed", c.getDescription());
	}

	@Test 
	void setDescriptionTest() {
		assertEquals("Ashraf Abdulhameed", c.getDescription());
		c.setDescription("This assignment was soo difficult");
		assertEquals("This assignment was soo difficult", c.getDescription());
	}


	@Test
	void getChBookTest() {
		assertEquals("Group Work", c.getChBook());
	}

	@Test
	void setChBookTest() {
		assertEquals("Group Work", c.getChBook());
		c.setChBook("Too much Stress");
		assertEquals("Too much Stress", c.getChBook());
	}

	}





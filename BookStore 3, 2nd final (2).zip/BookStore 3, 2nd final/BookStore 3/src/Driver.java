import java.util.Scanner;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.DomDriver;


import java.io.FileReader;
import java.io.FileWriter;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.*;
/**
 * 
 * @author Emily Lukuta and Asharaf Abdulhameed.
 *
 *Diver class
 */
public class Driver {
	
	
	/**
	 * Instances/Variables.
	 */
	 private Scanner input;
	 private Book book;
	 private Character character;
	 private Library library;
	 
	public Driver() {
		
		 input = new Scanner(System.in);
		 library = new Library();

	        runMenu();	
	}
	
	
	/**
	 *Contents inside this function are excecuted when this program is ran.  
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Driver application = new Driver();
	}
	
	
	/**
	 * Method for Main Menu to view in our Console.
	 * @return
	 */
	private int mainMenu()
    { 
        System.out.println("*****Welcome to our Book store Menu****");
        System.out.println("----------------------------------------");     
        System.out.println("  1) Add a book");    
        System.out.println("  2) Add a character");
        System.out.println("---------");
        System.out.println("  3) Delete a Book ");
        System.out.println("  4) Delete a Character");
        System.out.println("---------");
        System.out.println("  5) List of books");        
        System.out.println("  6) List of characters");
        System.out.println("---------");
        System.out.println("  7) Sort books  A-Z "); 
        System.out.println("  8) Sort characters A-Z");
        System.out.println("---------");
        System.out.println("  9) Edit Book ");
        System.out.println(" 10) Edit Character");
        System.out.println("---------");
        System.out.println(" 11) Update Book's name");
        System.out.println(" 12) Update Character's name");
        System.out.println("---------");
        System.out.println(" 13) Associate Character to Book");
        System.out.println(" 14) Associate Book to Character");
        System.out.println("---------");
        System.out.println(" 15) search for a book by Name");
        System.out.println(" 16) search for a book by Author"); 
        System.out.println(" 17) search for a book by Genre"); 
        System.out.println(" 18) search for a character by Name");
        System.out.println(" 19) search for a character by Book Title");
        System.out.println("---------");
        System.out.println(" 20) Save");
        System.out.println(" 21) Load");
        System.out.println("---------");
        System.out.println("  0) Exit");
        System.out.print("==>> ");
        int option = input.nextInt();
        return option;
    }
    
	
	/**
	 * Cases containing methods/functions in which a user has options to choose from.
	 */
	private void runMenu()
    {
        int option = mainMenu();
        while (option != 0)
        {
           
            switch (option)
            {
               case 1:    addBook();
                          break;
               case 2:    addCharacter();
                          break;
               case 3:    removeBook();
            	          break;
               case 4:    removeCharacter();
            	   		  break;
               case 5:   getBooks();
            	   		  break;
               case 6:   getCharacters();
            	   		  break;
               case 7:   sortBooks();
            	   		  break;
               case 8:    sortCharacters();
               case 9:    editBook();
            	   		  break;
               
               case 10:   editCharacter();
               			  break;
               			  
               case 11:	  updateBook(book);
               			  break;
               			  
               case 12:updateCharacter(character);
    			  break;
    			  
               case 13: linkBooksToCharacter();
               			  break;
               case 14:  linkCharacterToBook();
     	          break;
     	          
               case 15:   findBook();
 	   		  break;
 	   		  
               case 16:   findBookAuthor();
  	   		  break;
  	   		  
               case 17:   findBookGenre();
  	   		  break;
               case 18:   findCharacter();
     		  break;
               case 19:   findCharacterChBook();
        		  break;
    		   
               case 20:    try{
   	   						save();
	   			  		  }
	   			  		  catch (Exception e){
	   			  			System.out.println("Error writing to file: " + e);
	   			  		  }      
      			  		  break;
               case 21:   try{
   	   					    load();
      			          }
     			  		  catch (Exception e)
      			          { 
      			  			System.out.println("Error reading from file: " + e);
      			          }
      		              break;
            
               default:
   				System.out.println("Invalid option entered: " + option);
   				break;
   			}

          /**
   			*  pause the program so that the user can read what we just printed to the
   		    *
   			* terminal window
   			*
   			* */
   			System.out.println("\nPress any key to continue...");
   			input.nextLine();
   			input.nextLine(); // this second read is required - bug in Scanner class; a String read is ignored
   								// straight after reading an int.

   			// display the main menu again
   			option = mainMenu();
   		}

   		// the user chose option 0, so exit the program
   		System.out.println("Exiting... bye");
   		System.exit(0);
   	}
	
	
	/**
	 * Method To link Character to book
	 */
	private void linkCharacterToBook() {
		
			System.out.println("-------Please enter name of Book in which to add Character");
			System.out.println("Please enter the Book Title:"); 
			String title= input.nextLine();
			title = input.nextLine();
			
			Book book= library.findBook(title);
			
			if(book != null) {
				getCharacters();
				System.out.println();
				System.out.println("Please enter location number of character to add:");
				int index = input.nextInt();
				CharacterTable characters = library.getCharacters();
				book.associateCharacter(characters.getByIndex(index));
			}
			else {
				System.out.println("Character not found");
			}	
		}
	
	
	/**
	 * Method to link Book to Character.
	 */
	private void linkBooksToCharacter() {
		System.out.println("-------Please enter name of character in which to add book");
		System.out.println("Please enter name of Character:"); 
		String name = input.nextLine();
		name = input.nextLine();
		
		Character character = library.findCharacter(name);
		
		if(character != null) {
			getBooks();
			System.out.println();
			System.out.println("Please enter location number of book to add:");
			int index = input.nextInt();
			BookTable books = library.getBooks();
			character.associateBook(books.getByIndex(index));
		}
		else {
			System.out.println("Character not found");
		}	
	}
	
	
	/**
	 * Method for Interface to Delete/Remove Character from System.
	 */
	private void removeCharacter() {
		System.out.println("-------Please enter name of character to remove");
		System.out.println("Please enter name of Character:"); 
		String name = input.nextLine();
		name = input.nextLine();
		
		Character character = library.findCharacter(name);
		
		if(character != null) {
			if(library.removeCharacter(character))
				System.out.println("Character deleted successfully");
			else
				System.out.println("Unable to delete character");
		}
		else {
			System.out.println("Character not found");
		}
	}
	
	
	/**
	 * Method for Interface to Delete/Remove Book from System.	
	 */
	private void removeBook() {
		System.out.println("-------Please enter the name of Book to remove");
		System.out.println("Please enter Book Title:"); 
		String title = input.nextLine();
		title = input.nextLine();
		
		Book book = library.findBook(title);
		
		if(book != null) {
			if(library.removeBook(book))
				System.out.println("Book deleted successfully");
			else
				System.out.println("Unable to delete Book");
		}
		else {
			System.out.println("Book not found");
			}
	}
	
	
	/**
	 * Method for Interface to Sort Books A-Z the System.
	 */
	private void sortBooks() {
		if(library.getBooks().size() > 0) {
		Book[] sortedList = library.getBooks().sort();
		System.out.println(library.getBooks().listBooks(sortedList));
	} else {
   		  System.out.println("No books in library");
		}	
	}
	
	
   /**
	*Method for Interface to Delete/Remove Character from System.
	*/
	private void sortCharacters() {
		if(library.getCharacters().size() > 0) {
			Character[] sortedList = library.getCharacters().sort();
			System.out.println(library.getCharacters().listCharacters(sortedList));
		} else {
	   		  System.out.println("No books in library");
		}
	}

	
	   /**
		*Method for Interface to List Books in the System.
		*/
	private void getBooks() {
		// TODO Auto-generated method stub
		if(library.getBooks().size() > 0) {
	   		  System.out.println(library.getBooks().listBooks());
		} else {
	   		  System.out.println("No books in library");
		}
	}
	
	private void getCharacters() {
		// TODO Auto-generated method stub
		if(library.getCharacters().size() > 0) {
	   		  System.out.println(library.getCharacters().listCharacters());
		} else {
	   		  System.out.println("No books in library");
		}
	}

	
	   /**
		*Method for Interface to Add Character into the System.
		*/
	public void addCharacter() {
		System.out.println("Please enter name of Character:"); 
		String name = input.nextLine();
		name = input.nextLine();
		
		System.out.println("Please enter name of books the character appears in :"); 
		String chBook = input.nextLine();
		//chBook = input.nextLine();
		
		System.out.println("Please Enter Book id:");
		int id = input.nextInt();
		
		System.out.println("Character's Gender M/F:");
		String gender = input.nextLine();
		gender = input.nextLine();
		
		System.out.println("Please enter the characters Description(...role play etc):");
		String description = input.nextLine();
		
		System.out.println("name:" + name);
		System.out.println(" Book id :"+ id );
		System.out.println(" Gender :"+ gender);
		System.out.println(" Books :"+ chBook);
		System.out.println(" Description:"+ description );
		
		Character character = new Character(name, gender, id, chBook, description);
		library.addCharacter(character);
		
	}
	
	
	   /**
		*Method for Interface to Edit A book in the System.
		*/
	public void editBook() {
		System.out.println("-------Please enter name Book to edit");
		System.out.println("Please enter Book Title:"); 
		String title = input.nextLine();
		title = input.nextLine();
			
		Book book = library.findBook(title);
		
		if(book != null) {
			updateBook(book);
		}
		else {
			System.out.println("Book not found");
			}
		}
	
	
	   /**
		*Method for Interface to edit Character in the System.
		*/
	public void editCharacter() {
		
		System.out.println("-------Please enter name of character to edit");
		System.out.println("Please enter name of Character:"); 
		String name = input.nextLine();
		name = input.nextLine();
			
		Character character = library.findCharacter(name);
		
		if(character != null) {
			updateCharacter(character);
		}
		else {
			System.out.println("Character not found");
		}	
	}
	
	
	   /**
		*Method for Interface to Update a Book in the System.
		*/
	public void updateBook(Book book) {

		System.out.println("Please enter title of book:"); 
		String title = input.nextLine();
		//title = input.nextLine();
		book.setTitle(title);
		System.out.println("Please enter Author of book:");
		String author = input.nextLine();
		book.setAuthor(author);
		//author = input.nextLine();
		System.out.println("Please enter publisher of book:"); 
		String publisher = input.nextLine();
		book.setPublisher(publisher);
		//publisher = input.nextLine();
		System.out.println("Please Enter Year of Publication:");
		int yearOfPublication = input.nextInt();
		book.setYearOfPublication(yearOfPublication);
		System.out.println("Please enter book Genre:"); 
		String genre = input.nextLine();
		genre = input.nextLine();
		book.setGenre(genre);
		System.out.println("Please Enter no. of Pages:");
		int noPages = input.nextInt();
		book.setNoPages(noPages);
		System.out.println("Please enter the book Description(...role plot description etc):");
		input.nextLine();
		String description = input.nextLine();
		book.setDescription(description);
		//description = input.nextLine();
		System.out.println("Please Enter Book ID:");
		int bookId = input.nextInt();
		book.setBookId(bookId);
		
		System.out.println(" Title of the book :"+ title);
		System.out.println(" Year of Publication :"+ yearOfPublication);
		System.out.println(" Publisher:"+ publisher );
		System.out.println(" No. Of Pages:"+ noPages );
		System.out.println(" Plot Description :"+ description);
		System.out.println(" Genre of the book :"+ genre);
		System.out.println(" Book ID :"+ bookId);
		
	}
	
	
   /**
	*Method for Interface to Update a Character in the System.
	*/
	public  void updateCharacter(Character character) {
		System.out.println("Please enter new name of Character:"); 
		String name = input.nextLine();
		character.setName(name);
		
		System.out.println("Please enter name of books the character appears in :"); 
		String chBook = input.nextLine();
		character.setChBook(chBook);
		
		System.out.println("Character's Gender M/F:");
		String gender = input.nextLine();
		character.setGender(gender);
		
		System.out.println("Please enter the characters Description(...role play etc):");
		String description = input.nextLine();
		character.setDescription(description);
		
		System.out.println("name:" + name);
		System.out.println(" Book id :"+ character.getId());
		System.out.println(" Gender :"+ gender);
		System.out.println(" Books :"+ chBook);
		System.out.println(" Description:"+ description );
		
	}
	
	
	/**
	*Method for Interface to Add a Book into the System.
	*/
	public void addBook() {
		System.out.println("Please enter title of book:"); 
		String title = input.nextLine();
		title = input.nextLine();
		System.out.println("Please enter Author of book:");
		String author = input.nextLine();
		//author = input.nextLine();
		System.out.println("Please enter publisher of book:"); 
		String publisher = input.nextLine();
		//publisher = input.nextLine();
		System.out.println("Please Enter Year of Publication:");
		int yearOfPublication = input.nextInt();
		System.out.println("Please enter book Genre:"); 
		String genre = input.nextLine();
		genre = input.nextLine();
		System.out.println("Please Enter no. of Pages:");
		int noPages = input.nextInt();
		System.out.println("Please enter the book Description(...role plot description etc):");
		input.nextLine();
		String description = input.nextLine();
		//description = input.nextLine();
		System.out.println("Please Enter Book ID:");
		int bookId = input.nextInt();
		
		System.out.println(" Title of the book :"+ title);
		System.out.println(" Year of Publication :"+ yearOfPublication);
		System.out.println(" Publisher:"+ publisher );
		System.out.println(" Plot Description :"+ description);
		System.out.println(" Genre of the book :"+ genre);
		System.out.println(" Book ID :"+ bookId);
		
		Book book = new Book(title, author, publisher, yearOfPublication, noPages,description,genre,bookId);
		library.addBook(book);
	}
	
	
	/**
	*Method for Interface to Search for a Book in the System by Book Title.
	*/
	public void findBook() {System.out.println("-------Find book by name");
	System.out.println("Please enter name of Book:"); 
	String title = input.nextLine();
	title = input.nextLine();
	
	Book book = library.findBook(title);
	
	if(book != null)
		System.out.println(book);
	else
		System.out.println("Book not found");
	}
	public void findBookAuthor() {System.out.println("-------Find book by Author");
	System.out.println("Please enter Author of Book:"); 
	String author = input.nextLine();
	author  = input.nextLine();
	
	Book book = library.findBookAuthor(author);
	
	if(book != null)
		System.out.println(book);
	else
		System.out.println("Book not found");
	}
	
	
	/**
	*Method for Interface to Search for a Book in the System by Book Genre.
	*/
	public void findBookGenre() {System.out.println("-------Find book by Genre");
	System.out.println("Please enter Genre of Book:"); 
	String genre = input.nextLine();
	genre = input.nextLine();
	
	Book book = library.findBook(genre);
	
	if(book != null)
		System.out.println(book);
	else
		System.out.println("Book not found");
	}
	
	
	/**
	*Method for Interface to Search for a Character in the System by Character Name.
	*/
	public void findCharacter(){
		System.out.println("-------Find character by name");
		System.out.println("Please enter name of Character:"); 
		String name = input.nextLine();
		name = input.nextLine();
		
		Character character = library.findCharacter(name);
		
		if(character != null)
			System.out.println(character);
		else
			System.out.println("Character not found");
		
		//System.out.println(characterTable.find(character));
	}
	
	
	/**
	*Method for Interface to Search for a Character in the System by Book Title.
	*/
	public void findCharacterChBook(){
		
		System.out.println("-------Find character by Character's book");
		System.out.println("Please enter book title character appears in:"); 
		String chBook = input.nextLine();
		chBook = input.nextLine();
		
		Character character = library.findCharacterChBook(chBook);
		
		if(character != null)
			System.out.println(character);
		else
			System.out.println("Character not found");
		
		//System.out.println(characterTable.find(character));
	}
	
	
	/**
	*Save and Load Facility
	*/
	@SuppressWarnings("unchecked")
    public void load() throws Exception
    {
        XStream xstream = new XStream(new DomDriver());
        ObjectInputStream is = xstream.createObjectInputStream(new FileReader("save.xml"));
        library = (Library) is.readObject();
        is.close();
    }
    
	public void save() throws Exception
    {
        XStream xstream = new XStream(new DomDriver());
        ObjectOutputStream out = xstream.createObjectOutputStream(new FileWriter("save.xml"));
        out.writeObject(library);
        out.close();    
    }

}

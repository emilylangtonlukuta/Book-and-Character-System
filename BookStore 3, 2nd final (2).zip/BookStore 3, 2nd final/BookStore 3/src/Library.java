/**
 * 
 * @author Emily Lukuta and Ashraf Abdulhameed
 * 
 * Library class 
 * Contains Called methods From book and character classes.
 *
 */
public class Library {
	
	private BookTable bookTable;
	private CharacterTable characterTable;
	 
	public Library() {
		bookTable = new BookTable(99);
		characterTable = new CharacterTable(100);
	}
	
	public void addBook(Book book) {
		bookTable.add(book);
	}
	
	public void addCharacter(Character character) {
		characterTable.add(character);
	}
	
	public BookTable getBooks() {
		return this.bookTable;
	}
	
	public CharacterTable getCharacters() {
		return this.characterTable;
	}
	
	public boolean removeBook(Book book) {
		return this.bookTable.removeItem(book);}
	
	public boolean removeCharacter(Character character) {
		return this.characterTable.removeItem(character);
	}
	public Book findBookAuthor(String query) {
		return this.bookTable.searchAuthor(query);}
	
	public Book findBookGenre(String query) {
		return this.bookTable.searchGenre(query);}
	
	public Book findBook(String query) {
		return this.bookTable.search(query);}
		
	public Character findCharacter(String query) {
		return this.characterTable.search(query);	
	}
	public Character findCharacterChBook(String query) {
		return this.characterTable.searchChBook(query);	
	}
}

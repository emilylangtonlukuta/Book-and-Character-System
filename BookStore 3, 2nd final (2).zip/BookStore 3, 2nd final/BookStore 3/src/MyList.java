import java.util.*;
import java.lang.Object;
/**
 * 
 * @author Emily Lukuta and Ashraf Abdulhameed.
 *
 *Generic Linked List
 * @param <T>
 */
public class MyList<T> implements Iterable<T> {
	public MyNode<T> head = null;

	
	public void addElement (T e) {
		MyNode<T> cb=new MyNode<>();
		cb.setContents (e);
		cb.next=head;
		head=cb;
		//if(contains(e)) return false;
		//MyNode<T> cb = new MyNode<> (e);
		//cb.next=head;
		//head=cb;
		//return true;
	}
	
	
	public boolean contains(T e) {
		MyNode<T>temp = head;
		while(temp != null && !temp.contents.equals(e))
			temp=temp.next;
		
		if(temp != null) {
			return true;
		}
		return false;
	}
	
	/*public boolean removeB(T e) {
		MyNode<T>temp = head, ;
		while(temp != null && !temp.contents.equals(e))
			temp=temp.
		/*for(T x : this)
			if(x.equals(e)) return true;
		return false;
	}*/
	
	
	
	public void clear() {
		head=null;
	}
	
	class MyNode<N> {
		public MyNode<N> next=null;
		private N contents;
		
		public N getContents() {
			return contents;
		}
		public void setContents(N contents) {
			this.contents = contents;
		}
		
		
		
	}

	@Override
	public Iterator<T> iterator() {
		// TODO Auto-generated method stub
		return null;
	}

}
